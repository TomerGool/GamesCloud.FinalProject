package com.example.android1finalproject.data;

import android.os.StrictMode;

import com.example.android1finalproject.models.Categories;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import io.grpc.internal.JsonParser;

public class DataService {
    private ArrayList<Categories> arrCat = new ArrayList<>();
    public ArrayList<Categories> getCategory()
    {
        String Surl = "https://android1finalproject-29c6e-default-rtdb.firebaseio.com/";

        URL url = null;
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try
        {
            url = new URL(Surl);

        }catch(MalformedURLException e)
        {
            throw new RuntimeException(e);
        }
        HttpURLConnection request = null;
        try{
            request = (HttpURLConnection) url.openConnection();
            request.connect();
            /*JsonParser js = new JsonParser();*/



        }catch(IOException e)
        {
            throw new RuntimeException(e);
        }
        return null;
    }
}
