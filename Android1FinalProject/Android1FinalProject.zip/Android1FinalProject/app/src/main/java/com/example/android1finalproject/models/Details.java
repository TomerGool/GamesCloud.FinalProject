package com.example.android1finalproject.models;

public class Details {
    private String description;
    private String adminName;
    private String date;
    private String location;
    private String numParticipant;
    private String time;
    private String maxPlayers;
    private String minPlayers;



    public Details(String adminName, String date, String location, String maxPlayers) {
        this.adminName = adminName;
        this.date = date;
        this.location = location;
        this.maxPlayers = maxPlayers;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getNumParticipant() {
        return numParticipant;
    }

    public void setNumParticipant(String numParticipant) {
        this.numParticipant = numParticipant;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getMaxPlayers() {
        return maxPlayers;
    }

    public void setMaxPlayers(String maxPlayers) {
        this.maxPlayers = maxPlayers;
    }

    public String getMinPlayers() {
        return minPlayers;
    }

    public void setMinPlayers(String minPlayers) {
        this.minPlayers = minPlayers;
    }
}
